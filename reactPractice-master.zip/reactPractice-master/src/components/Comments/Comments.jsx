export default function Comments() {
  return <div>Comments</div>;
}
