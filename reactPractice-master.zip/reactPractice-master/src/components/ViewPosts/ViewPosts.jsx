const ViewPosts = () => {
  return <div>ViewPosts</div>;
};

export default ViewPosts;
