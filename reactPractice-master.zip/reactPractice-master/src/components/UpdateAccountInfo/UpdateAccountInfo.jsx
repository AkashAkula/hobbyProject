export default function UpdateAccountInfo() {
  return <div>This is footer</div>;
}
