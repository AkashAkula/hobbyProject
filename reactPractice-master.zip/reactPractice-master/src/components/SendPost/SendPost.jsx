export default function SendPost() {
  return <div>SendPost</div>;
}
